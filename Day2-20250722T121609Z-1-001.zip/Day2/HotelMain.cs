﻿// See https://aka.ms/new-console-template for more information
using System;
class Start
{

// static void Main()
// {

//     Console.WriteLine(" Entry Point of your program");
//    // All variables like local or reference are stored in stack
//     // All objects are stored in heap memory
//     Employee e = new Employee();
//     Console.WriteLine(e.GetType());
//     Console.WriteLine(e.GetHashCode());
//     e.Input();
//     e.Display();

// }

}
